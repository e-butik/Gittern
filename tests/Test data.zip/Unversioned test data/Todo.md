# Todo

## Buy a new computer
* ~~Research computers~~
* Choose a computer
* Buy it